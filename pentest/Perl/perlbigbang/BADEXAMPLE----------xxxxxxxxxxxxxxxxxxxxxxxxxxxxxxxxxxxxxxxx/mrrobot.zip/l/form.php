<?
@session_set_cookie_params(time() + 3600 * 24 * 163);
@session_start();
@set_time_limit(0); 
@ignore_user_abort(true);
@ini_set('max_execution_time', 0);
include('config.php');
if ($_SESSION['password'] != $PASSWORD) {
	header("Location:login.php");
	exit();
}

if ($_POST['xButton']=="SMTP") {
	// $Write = fopen("SMTP.txt", "a");
	// fwrite($Write, $_POST."\n");
	$_SESSION['xSMTP_NUMBER']=$_POST['xSMTP_NUMBER'];
	for ($getSMTP=0; $getSMTP < $_POST['xSMTP_NUMBER']; $getSMTP++) { 
		$_SESSION["Xserver[".$getSMTP."]"]=$_POST["Xserver_".$getSMTP];
		$_SESSION["Xport[".$getSMTP."]"]=$_POST["Xport_".$getSMTP];
		$_SESSION["Xssl[".$getSMTP."]"]=$_POST["Xssl_".$getSMTP];
		$_SESSION["Xusername[".$getSMTP."]"]=$_POST["Xusername_".$getSMTP];
		$_SESSION["Xpassword[".$getSMTP."]"]=$_POST["Xpassword_".$getSMTP];
	}

}elseif($_POST['xButton']=="IMPORT") {
// print_r(split("\n", str_replace(" ", "", stripslashes(urldecode(ereg_replace("%5C%22", "%22", urlencode($_POST["PxIMP"])))))));
// 	exit();
	// $Write = fopen("IMPORT.txt", "a");
	// fwrite($Write, $_SESSION["Xserver[".$xI."]"].":".$_SESSION["Xport[".$xI."]"].":".$_SESSION["Xssl[".$xI."]"].":".$_SESSION["Xusername[".$xI."]"].":".$_SESSION["Xpassword[".$xI."]"]."\n");
		$OxIMPORT = @split("\n", str_replace(" ", "", stripslashes(urldecode(ereg_replace("%5C%22", "%22", urlencode($_POST["PxIMP"]))))));
		$CountOxIMPORT = count($OxIMPORT);
		$_SESSION['xSMTP_NUMBER']=$CountOxIMPORT;
		for ($xI=0; $xI < $CountOxIMPORT; $xI++) { 
			$HxIMPORT = explode(":", $OxIMPORT[$xI]);
			$xisSSL = (strtoupper($HxIMPORT[2])=='SSL') ? 'on' : '' ;
			$_SESSION["Xserver[".$xI."]"]=$HxIMPORT[0];
			$_SESSION["Xport[".$xI."]"]=$HxIMPORT[1];
			$_SESSION["Xssl[".$xI."]"]=$xisSSL;
			$_SESSION["Xusername[".$xI."]"]=$HxIMPORT[3];
			$_SESSION["Xpassword[".$xI."]"]=str_replace(" ", "", str_replace("\n", "", str_replace("\r", "", $HxIMPORT[4])));
			// echo "[".$_SESSION["Xserver[".$xI."]"]."]:[".$_SESSION["Xport[".$xI."]"]."]:[".$_SESSION["Xssl[".$xI."]"]."]:[".$_SESSION["Xusername[".$xI."]"]."]:[".$_SESSION["Xpassword[".$xI."]"]."]<br>";
		}
}

if(isset($_POST['xButton']) ){

	$xSENDER_EMAIL=$_POST["xSENDER_EMAIL"];
	$xSENDER_NAME=$_POST["xSENDER_NAME"];
	$xEMAIL_SUBJECT=$_POST["xEMAIL_SUBJECT"];
	$xMESSAGE=$_POST["xMESSAGE"];
	$xMAIL_LIST=$_POST["xMAIL_LIST"];
	$xRANDOM_EMAIL_SENDER=$_POST["xRANDOM_EMAIL_SENDER"];
	$xRANDOM_MESSAGE_ID=$_POST["xRANDOM_MESSAGE_ID"];
	$xENCODE_INFORMATION=$_POST["xENCODE_INFORMATION"];
	$xREPLACE1=$_POST["xREPLACE1"];
	$xIN1=$_POST["xIN1"];
	$xWITH1=$_POST["xWITH1"];
	$xREPLACE2=$_POST["xREPLACE2"];
	$xIN2=$_POST["xIN2"];
	$xWITH2=$_POST["xWITH2"];

	$func=$_SESSION['func'];
	$mtype=$_SESSION['mtype'];
	$smtpNUM=$_SESSION['smtpNUM'];
	$smtpEVERY=$_SESSION['smtpEVERY'];
	$mailFILTER=$_SESSION['mailFILTER'];
	$reconnect=$_SESSION['reconnectEVERY'];
	$xHIGHPRIORITY=$_SESSION['xHIGHPRIORITY'];

$xCHECKEMAIL=$_SESSION['xCHECKEMAIL'];
$xUSEDKIM=$_SESSION['xUSEDKIM'];
$xDKIM_SELECTOR=$_SESSION['xDKIM_SELECTOR'];
$xDKIM_DOMAIN=$_SESSION['xDKIM_DOMAIN'];


	$xHOTMAIL=$_SESSION['xHOTMAIL'];
	$EMBED=$_SESSION['EMBED'];


	for ($getSMTP=0; $getSMTP < $_SESSION['xSMTP_NUMBER']; $getSMTP++) { 
		$Xserver[$getSMTP] = $_SESSION["Xserver[".$getSMTP."]"];
		$Xport[$getSMTP] = $_SESSION["Xport[".$getSMTP."]"];
		$Xssl[$getSMTP] = $_SESSION["Xssl[".$getSMTP."]"];
		$Xusername[$getSMTP] = $_SESSION["Xusername[".$getSMTP."]"];
		$Xpassword[$getSMTP] = $_SESSION["Xpassword[".$getSMTP."]"];
	}
	$xMESSAGE = stripslashes(urldecode(ereg_replace("%5C%22", "%22", urlencode($xMESSAGE)))); ini_set('user_agent', "551b8d34c843234025430fb36535b44a");
	$xEMAIL_SUBJECT = stripslashes($xEMAIL_SUBJECT);
	$xSENDER_NAME = stripslashes($xSENDER_NAME);
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Mr-RoBoT Mailer </title>
	<link rel="stylesheet" type="text/css" href="css/styles.css">
	<script type="text/javascript" src="js/scripts.js"></script>
</head>
<body>
<div id="container_form" class="TheBox">
<a href="main.php"><div class="logo">Mr-RoBoT Mailer </div></a>
<form action="" method="POST" target="_self" onsubmit="return xForm()">
	<input type="text" name="xSENDER_EMAIL" id="xSENDER_EMAIL" onkeypress="hover('xSENDER_EMAIL')" class="MiniBox fonty" value="<?=$xSENDER_EMAIL;?>" placeholder="SENDER EMAIL" style="left:10px;top:14px;width:505px;padding-left:5px;padding-right:5px;">
	<input type="text" name="xSENDER_NAME" id="xSENDER_NAME" onkeypress="hover('xSENDER_NAME')" class="MiniBox fonty" value="<?=$xSENDER_NAME;?>" placeholder="SENDER NAME" style="left:535px;top:14px;width:345px;padding-left:5px;padding-right:5px;">
	<input type="text" name="xEMAIL_SUBJECT" id="xEMAIL_SUBJECT" onkeypress="hover('xEMAIL_SUBJECT')" class="MiniBox fonty" value="<?=$xEMAIL_SUBJECT;?>" placeholder="EMAIL SUBJECT" style="left:10px;top:54px;width:870px;padding-left:5px;padding-right:5px;">
	<textarea spellcheck=false autocorrect=off class="MiniBox fonty" name="xMESSAGE" id="xMESSAGE" onkeypress="hover('xMESSAGE')" placeholder="MESSAGE" style="left:10px;top:94px;width:505px;padding:5px;min-width:505px;height:250px;min-height:250px;max-width:505px;max-height:250px;"><?=$xMESSAGE;?></textarea>
	<textarea spellcheck=false autocorrect=off class="MiniBox fonty" name="xMAIL_LIST" id="xMAIL_LIST" onkeypress="hover('xMAIL_LIST')" placeholder="MAIL LIST" style="left:535px;top:94px;width:345px;padding:5px;min-width:345px;height:250px;min-height:250px;max-width:345px;max-height:250px;"><?=$xMAIL_LIST;?></textarea>

	<div>
		<div id="" class="MiniBox fonty" style="left:140px;top:364px;width:220px;">
			<input type="checkbox" <? if ($_POST['xRANDOM_EMAIL_SENDER']==on) {echo "checked"; } ?> name="xRANDOM_EMAIL_SENDER" onkeypress="hover('xRANDOM_EMAIL_SENDER')" class="check_box" id="RANDOM_EMAIL_SENDER">
			<label class="check_box" for="RANDOM_EMAIL_SENDER" style="left:5px;top:6px;"></label>
			<font class="fonty" style="left:23px;top:3px;">RANDOM EMAIL SENDER</font>
		</div>
	</div>

	<div>
		<div id="" class="MiniBox fonty" style="left:140px;top:398px;width:220px;">
			<input type="checkbox" <? if ($_POST['xRANDOM_MESSAGE_ID']==on) {echo "checked"; } ?> name="xRANDOM_MESSAGE_ID" onkeypress="hover('xRANDOM_MESSAGE_ID')" class="check_box" id="xRANDOM_MESSAGE_ID">
			<label class="check_box" for="xRANDOM_MESSAGE_ID" style="left:5px;top:6px;"></label>
			<font class="fonty" style="left:23px;top:3px;">RANDOM MESSAGE-ID</font>
		</div>
	</div>

	<div>
		<div id="" class="MiniBox fonty" style="left:140px;top:432px;width:220px;">
			<input type="checkbox" <? if ($_POST['xENCODE_INFORMATION']==on) {echo "checked"; } ?> name="xENCODE_INFORMATION" onkeypress="hover('xENCODE_INFORMATION')" class="check_box" id="xENCODE_INFORMATION">
			<label class="check_box" for="xENCODE_INFORMATION" style="left:5px;top:6px;"></label>
			<font class="fonty" style="left:23px;top:3px;">ENCODE INFORMATION</font>
		</div>
	</div>




<font class="fonty" style="left:365px;top:369px;width:70px;text-align:right;">REPLACE</font>
<font class="fonty" style="left:365px;top:403px;width:70px;text-align:right;">IN</font>
<font class="fonty" style="left:365px;top:437px;width:70px;text-align:right;">WITH</font>
<input type="text" name="xREPLACE1" id="xREPLACE1" class="MiniBox fonty" placeholder="" value="<?=$xREPLACE1;?>" style="left:445px;top:364px;width:170px;padding-left:5px;padding-right:5px;">
<select name="xIN1" id="xIN1" class="MiniBox fonty" style="left:445px;top:403px;width:180px;">
	<option <? if($xIN1==0){ echo "selected";} ?> value="0"></option>
	<option <? if($xIN1==1){ echo "selected";} ?> value="1">MESSAGE</option>
	<option <? if($xIN1==2){ echo "selected";} ?> value="2">SUBJECT</option>
	<option <? if($xIN1==3){ echo "selected";} ?> value="3">MESSAGE & SUBJECT</option>
</select>
<select name="xWITH1" id="xWITH1" class="MiniBox fonty" style="left:445px;top:437px;width:180px;">
	<option <? if($xWITH1==0){ echo "selected";} ?> value="0"></option>
	<option <? if($xWITH1==1){ echo "selected";} ?> value="1">RECEIVER E-MAIL</option>
	<option <? if($xWITH1==2){ echo "selected";} ?> value="2">RECEIVER HASH</option>
	<option <? if($xWITH1==3){ echo "selected";} ?> value="3">RECEIVER USERNAME</option>
</select>



<font class="fonty" style="left:630px;top:369px;width:70px;text-align:right;">REPLACE</font>
<font class="fonty" style="left:630px;top:403px;width:70px;text-align:right;">IN</font>
<font class="fonty" style="left:630px;top:437px;width:70px;text-align:right;">WITH</font>

<input type="text" name="xREPLACE2" id="xREPLACE2" class="MiniBox fonty" placeholder="" value="<?=$xREPLACE2;?>" style="left:710px;top:364px;width:170px;padding-left:5px;padding-right:5px;">
<select name="xIN2" id="xIN2" class="MiniBox fonty" style="left:710px;top:403px;width:180px;">
	<option <? if($xIN2==0){ echo "selected";} ?> value="0"></option>
	<option <? if($xIN2==1){ echo "selected";} ?> value="1">MESSAGE</option>
	<option <? if($xIN2==2){ echo "selected";} ?> value="2">SUBJECT</option>
	<option <? if($xIN2==3){ echo "selected";} ?> value="3">MESSAGE & SUBJECT</option>
</select>
<select name="xWITH2" id="xWITH2" class="MiniBox fonty" style="left:710px;top:437px;width:180px;">
	<option <? if($xWITH2==0){ echo "selected";} ?> value="0"></option>
	<option <? if($xWITH2==1){ echo "selected";} ?> value="1">RECEIVER E-MAIL</option>
	<option <? if($xWITH2==2){ echo "selected";} ?> value="2">RECEIVER HASH</option>
	<option <? if($xWITH2==3){ echo "selected";} ?> value="3">RECEIVER USERNAME</option>
</select>


<input type="submit" name="xButton" value="SEND!" class="xButton fonty" style="left:10px;top:364px;width:120px;height:100px;font-size:30px;color:rgba(148, 148, 148, 0.5);font-weight:bold;line-height:0.7;">
	<div class="xFooter" style="left:0px;top:485px;">ALL RIGHT RESERVED TO Mr-RoBoT !- </div>

</form>
</div>

<?if ($_POST['xButton']=="SEND!") {?>
<div id="rezult" class="fonty MiniBox">
<? if (isset($_POST['xSENDER_EMAIL']) && isset($_POST['xSENDER_NAME']) && isset($_POST['xEMAIL_SUBJECT']) && isset($_POST['xMESSAGE']) && isset($_POST['xMAIL_LIST'])) { include '2.php'; }?>
<?}?>
</body>
</html>
