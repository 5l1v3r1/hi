<?
$PASSWORD="Dream666";
$USE_COMFIG = true; # true/false


	$FUNCTION = "smtp"; # mail/smtp
	$MAIL_TYPE = "html"; # html/text
	$CHANGE_SMTP_EVERY = 5000;
	$RECONNECT_SMTP_EVERY = 25;
	$FILTER_EMAILS = "";
	$EMBEDDING_NEWSLETTER_IN_MAILS = true; # true/false
	$USE_HOTMAIL_INBOX_METHOD = false; # true/false
	$HIGH_EMAIL_PRIORITY = true; # true/false
	$CHECK_IF_EMAIL_EXISTS = false; # true/false
	$USE_DKIM_SIGNATURE = false; # true/false
	$DKIM_DOMAIN = "";
	$DKIM_SELECTOR = "";
	$DKIM_RSA_PRIVATE_KEY = "";
?>