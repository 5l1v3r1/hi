function xForm(){
	if (document.getElementById('xSENDER_EMAIL').value.length < 1) {
		document.getElementById('xSENDER_EMAIL').style.borderColor = "rgba(255, 0, 0, 0.5)";return false;
	};
	if (document.getElementById('xSENDER_NAME').value.length < 1) {
		document.getElementById('xSENDER_NAME').style.borderColor = "rgba(255, 0, 0, 0.5)";return false;
	};
	if (document.getElementById('xEMAIL_SUBJECT').value.length < 1) {
		document.getElementById('xEMAIL_SUBJECT').style.borderColor = "rgba(255, 0, 0, 0.5)";return false;
	};
	if (document.getElementById('xMESSAGE').value.length < 1) {
		document.getElementById('xMESSAGE').style.borderColor = "rgba(255, 0, 0, 0.5)";return false;
	};
	if (document.getElementById('xMAIL_LIST').value.length < 1) {
		document.getElementById('xMAIL_LIST').style.borderColor = "rgba(255, 0, 0, 0.5)";return false;
	};

	if (document.getElementById('xREPLACE1').value.length > 0) {
		if (document.getElementById('xIN1').value == "0") {
			document.getElementById('xIN1').style.borderColor = "rgba(255, 0, 0, 0.5)";return false;
		};
		if (document.getElementById('xWITH1').value == "0") {
			document.getElementById('xWITH1').style.borderColor = "rgba(255, 0, 0, 0.5)";return false;
		};
	};
	if (document.getElementById('xREPLACE2').value.length > 0) {
		if (document.getElementById('xIN2').value == "0") {
			document.getElementById('xIN2').style.borderColor = "rgba(255, 0, 0, 0.5)";return false;
		};
		if (document.getElementById('xWITH2').value == "0") {
			document.getElementById('xWITH2').style.borderColor = "rgba(255, 0, 0, 0.5)";return false;
		};
	};
}
function hover(xThis) {
	if (xThis == "xSENDER_EMAIL") {
		document.getElementById('xSENDER_EMAIL').style.borderColor = "rgba(255, 255, 255, 0.15)";
	};
	if (xThis == "xSENDER_NAME") {
		document.getElementById('xSENDER_NAME').style.borderColor = "rgba(255, 255, 255, 0.15)";
	};
	if (xThis == "xEMAIL_SUBJECT") {
		document.getElementById('xEMAIL_SUBJECT').style.borderColor = "rgba(255, 255, 255, 0.15)";
	};
	if (xThis == "xMESSAGE") {
		document.getElementById('xMESSAGE').style.borderColor = "rgba(255, 255, 255, 0.15)";
	};
	if (xThis == "xMAIL_LIST") {
		document.getElementById('xMAIL_LIST').style.borderColor = "rgba(255, 255, 255, 0.15)";
	};

}










