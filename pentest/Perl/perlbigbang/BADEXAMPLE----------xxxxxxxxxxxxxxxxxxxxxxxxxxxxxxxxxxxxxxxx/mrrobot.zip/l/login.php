<?
@session_set_cookie_params(time() + 3600 * 24 * 163);
@session_start();
include('config.php');

if (isset($_SESSION['password']) && $_SESSION['password'] == $PASSWORD) {
	header("Location:main.php");
	exit();
}


if ($_POST['xButton']=="LOGIN" && $_POST['password']==$PASSWORD){
	$_SESSION['password'] = $_POST['password'];
	header("Location:main.php");
	exit();
}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Mr-RoBoT Mailer  - LOGIN</title>
	<link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<body>
<div id="container_main" class="TheBox" style="height:90px;">
<form name="form" action="" method="POST" target="_self">
	<div class="xTitle">Mr-RoBoT</div>
	<div>
		<font class="fonty" style="left:8px;top:15px;">PASSWORD</font>
		<input type="password" name="password" class="MiniBox fonty <? if (isset($_POST['password'])) { echo 'error';} ?>" value="" style="left:100px;top:11px;width:210px;padding-left:5px;padding-right:5px;">
	</div>

	<div>
		<input type="submit" name="xButton" value="LOGIN" class="xButton fonty" style="left:244px;top:50px;">
	</div>
	<div class="xFooter" style="left:0px;top:93px;">ALL RIGHT RESERVED TO Mr-RoBoT !<br></div>
</form>
</div>
</body>
</html>