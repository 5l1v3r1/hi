<?
@session_set_cookie_params(time() + 3600 * 24 * 163);
@session_start();
include('config.php');
if ($_SESSION['password'] != $PASSWORD) {
	header("Location:login.php");
	exit();
}
if (isset($_POST['func']) && isset($_POST['mtype']) && isset($_POST['smtpNUM']) && isset($_POST['smtpEVERY']) && isset($_POST['mailFILTER']) && isset($_POST['xButton'])) {
	$_SESSION['func']=$func=$_POST['func'];
	$_SESSION['mtype']=$mtype=$_POST['mtype'];
	$_SESSION['smtpNUM']=$smtpNUM=$_POST['smtpNUM'];
	$_SESSION['smtpEVERY']=$smtpEVERY=$_POST['smtpEVERY'];
	$_SESSION['mailFILTER']=$mailFILTER=$_POST['mailFILTER'];
	$_SESSION['reconnectEVERY']=$reconnectEVERY=$_POST['reconnectEVERY'];
	$_SESSION['xHOTMAIL']=$xHOTMAIL=$_POST['xHOTMAIL'];
	$_SESSION['xHIGHPRIORITY']=$xHIGHPRIORITY=$_POST['xHIGHPRIORITY'];
	$_SESSION['EMBED']=$EMBED=$_POST['EMBED'];
	$_SESSION['xCHECKEMAIL']=$xCHECKEMAIL=$_POST['xCHECKEMAIL'];
	$_SESSION['xUSEDKIM']=$xUSEDKIM=$_POST['xUSEDKIM'];
	$_SESSION['xDKIM_SELECTOR']=$xDKIM_SELECTOR=$_POST['xDKIM_SELECTOR'];
	$_SESSION['xDKIM_KEY']=$xDKIM_KEY=$_POST['xDKIM_KEY'];
	$_SESSION['xDKIM_DOMAIN']=$xDKIM_DOMAIN=$_POST['xDKIM_DOMAIN'];
	if (!empty($_POST['xDKIM_KEY'])) {
		$privatekey = fopen("privatekey.txt", "w");
		fwrite($privatekey, $_POST['xDKIM_KEY']);
		fclose($privatekey);
	}

	
	$_SESSION['xSMTP_NUMBER']=$xSMTP_NUMBER = (!is_numeric($smtpNUM)) ? "1" : $smtpNUM ;
	if ($func == "mail") {
		header("Location:form.php");
		exit();
	}
}else{
	header("Location:main.php");
	exit();
}




?>
<!DOCTYPE html>
<html>
<head>
	<title>Mr-RoBoT xMailer v1.3 - SMTP SETTING</title>
	<link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<body style="height:<? echo 90*$xSMTP_NUMBER+240 ;?>px;">
<div id="container_smtp" class="TheBox" style="top:10px;height:110px !important;">
<form name="form" action="form.php" method="POST" target="_self">
<textarea class="MiniBox fonty" spellcheck=false autocorrect=off id="PxIMP" name="PxIMP" style="left:8px;top:10px;width:420px;height:70px;padding-left:5px;padding-right:5px;min-width:420px;min-height:70px;max-width:420px;max-height:70px;" placeholder="SERVER:PORT:TLS/SSL:USERNAME:PASSWORD"></textarea>
<input type="submit" name="xButton" value="IMPORT" class="xButton fonty" style="left:355px;top:90px;">
</form>
</div>
<div id="container_smtp" class="TheBox" style="top:150px;height: <? echo 90*$xSMTP_NUMBER+20; ?>px !important;">
<form name="form" action="form.php" method="POST" target="_self">
<? for ($smtpX=0; $smtpX < $xSMTP_NUMBER; $smtpX++) { ?>
	<div style="top:<? echo $smtpX*90; ?>px;height:100px;" class="raw">
		<input type="text" name="Xserver_<?=$smtpX;?>" class="MiniBox fonty" placeholder="SMTP SERVER <?=$smtpX+1;?>" value="" style="left:8px;top:10px;width:230px;padding-left:5px;padding-right:5px;">
		<font class="fonty" style="left:255px;top:15px;"> : </font>
		<input type="text" name="Xport_<?=$smtpX;?>" class="MiniBox fonty" placeholder="PORT" value="" style="left:270px;top:10px;width:80px;padding-left:5px;padding-right:5px;">
		<div id="" class="MiniBox fonty" style="left:370px;top:11px;width:60px;">
			<input type="checkbox" name="Xssl_<?=$smtpX;?>" class="check_box" id="Xssl_<?=$smtpX;?>">
			<label class="check_box" for="Xssl_<?=$smtpX;?>" style="left:5px;top:6px;"></label>
			<font class="fonty" style="left:23px;top:3px;">SSL</font>
		</div>
		<input type="text" name="Xusername_<?=$smtpX;?>" class="MiniBox fonty" placeholder="USERNAME" value="" style="left:8px;top:50px;width:195px;padding-left:5px;padding-right:5px;">
		<input type="text" name="Xpassword_<?=$smtpX;?>" class="MiniBox fonty" placeholder="PASSWORD" value="" style="left:225px;top:50px;width:195px;padding-left:5px;padding-right:5px;">
	</div>
<? } ?>
	<input type="hidden" name="xSMTP_NUMBER" value="<?=$xSMTP_NUMBER;?>">
	<input type="submit" name="xButton" value="SMTP" class="xButton fonty" style="left:355px;top:<? echo 90*$xSMTP_NUMBER ;?>px;">
	<div class="xFooter" style="left:0px;top:<? echo 90*$xSMTP_NUMBER+42 ;?>px;">ALL RIGHT RESERVED TO Mr-RoBoT !<br></div>

</form>
</div>

</body>
</html>

