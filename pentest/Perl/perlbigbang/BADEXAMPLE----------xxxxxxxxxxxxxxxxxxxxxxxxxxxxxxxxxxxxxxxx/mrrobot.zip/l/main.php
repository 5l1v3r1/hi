<?
@session_set_cookie_params(time() + 3600 * 24 * 163);
@session_start();
include('config.php');
if ($_SESSION['password'] != $PASSWORD) {
	header("Location:login.php");
	exit();
}
if ($USE_COMFIG == true || $_POST['xLoad']=="xConfig") {
	$aFUNCTION = ($FUNCTION == "mail") ? "checked" : "" ;
	$bFUNCTION = ($FUNCTION == "smtp") ? "checked" : "" ;

	$aMAIL_TYPE = ($MAIL_TYPE == "html") ? "checked" : "" ;
	$bMAIL_TYPE = ($MAIL_TYPE == "text") ? "checked" : "" ;

	$aEMBEDDING_NEWSLETTER_IN_MAILS = ($EMBEDDING_NEWSLETTER_IN_MAILS == true) ? "checked" : "" ;
	$aUSE_HOTMAIL_INBOX_METHOD = ($USE_HOTMAIL_INBOX_METHOD == true) ? "checked" : "" ;
	$aHIGH_EMAIL_PRIORITY = ($HIGH_EMAIL_PRIORITY == true) ? "checked" : "" ;
	$aCHECK_IF_EMAIL_EXISTS = ($CHECK_IF_EMAIL_EXISTS == true) ? "checked" : "" ;
	$aUSE_DKIM_SIGNATURE = ($USE_DKIM_SIGNATURE == true) ? "checked" : "" ;
if ($USE_DKIM_SIGNATURE == true) {
	$aDKIM_DOMAIN=$DKIM_DOMAIN;
	$aDKIM_SELECTOR=$DKIM_SELECTOR;
	$aDKIM_RSA_PRIVATE_KEY=file_get_contents($DKIM_RSA_PRIVATE_KEY);
}
}else{

	$aFUNCTION = "checked";
	$bFUNCTION = "";

	$aMAIL_TYPE = "checked";
	$bMAIL_TYPE = "";

	$CHANGE_SMTP_EVERY = 500;
	$RECONNECT_SMTP_EVERY = 25;
	$FILTER_EMAILS = "";
	$aEMBEDDING_NEWSLETTER_IN_MAILS = "";
	$aUSE_HOTMAIL_INBOX_METHOD = "";
	$aHIGH_EMAIL_PRIORITY = "checked";
	$aCHECK_IF_EMAIL_EXISTS = "";
	$aUSE_DKIM_SIGNATURE = "checked";
	$aDKIM_DOMAIN="";
	$aDKIM_SELECTOR="";
	$aDKIM_RSA_PRIVATE_KEY="";
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Mr-RoBoT xMailer v1.3 - MAIN SETTING</title>
	<link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<body>
<div id="container_main" class="TheBox">
<form name="form" action="smtp.php" method="POST" target="_self">
	<div class="xTitle">Mr-RoBoT</div>
	<div>
		<font class="fonty" style="left:8px;top:12px;">FUNCTION</font>
		<div id="" class="MiniBox fonty" style="left:98px;top:8px;width:80px;">
			<input type="radio" <?=$aFUNCTION;?> name="func" value="mail" class="radio_box" id="func1">
			<label class="radio_box" for="func1" style="left:5px;top:6px;"></label>
			<font class="fonty" style="left:23px;top:3px;">MAIL()</font>
		</div>
		<font class="fonty" style="left:190px;top:12px;">OR</font>
		<div id="" class="MiniBox fonty" style="left:225px;top:8px;width:83px;">
			<input type="radio" <?=$bFUNCTION;?> name="func" value="smtp" class="radio_box" id="func2">
			<label class="radio_box" for="func2" style="left:5px;top:6px;"></label>
			<font class="fonty" style="left:23px;top:3px;">SMTP()</font>
		</div>
	</div>

	<div>
		<font class="fonty" style="left:8px;top:45px;">MAIL TYPE</font>
		<div id="" class="MiniBox fonty" style="left:98px;top:41px;width:80px;">
			<input type="radio" <?=$aMAIL_TYPE;?> name="mtype" value="html" class="radio_box" id="mtype1">
			<label class="radio_box" for="mtype1" style="left:5px;top:6px;"></label>
			<font class="fonty" style="left:23px;top:3px;">HTML</font>
		</div>
		<font class="fonty" style="left:190px;top:45px;">OR</font>
		<div id="" class="MiniBox fonty" style="left:225px;top:41px;width:83px;">
			<input type="radio" <?=$bMAIL_TYPE;?> name="mtype" value="text" class="radio_box" id="mtype2">
			<label class="radio_box" for="mtype2" style="left:5px;top:6px;"></label>
			<font class="fonty" style="left:23px;top:3px;">TEXT</font>
		</div>
	</div>
	<div>
		<font class="fonty" style="left:8px;top:80px;">CREATE</font>
		<input type="text" name="smtpNUM" class="MiniBox fonty" value="1" style="left:72px;top:74px;width:50px;padding-left:5px;padding-right:5px;">
		<font class="fonty" style="left:140px;top:80px;">SMTP ACCOUNTS</font>
	</div>
	<div>
		<font class="fonty" style="left:8px;top:113px;">CHANGE SMTP EVERY</font>
		<input type="text" name="smtpEVERY" class="MiniBox fonty" value="<?=$CHANGE_SMTP_EVERY;?>" style="left:180px;top:107px;width:50px;padding-left:5px;padding-right:5px;">
		<font class="fonty" style="left:250px;top:113px;">MAIL</font>
	</div>
	<div>
		<font class="fonty" style="left:8px;top:147px;">RECONNECT SMTP EVERY</font>
		<input type="text" name="reconnectEVERY" class="MiniBox fonty" value="<?=$RECONNECT_SMTP_EVERY;?>" style="left:205px;top:142px;width:50px;padding-left:5px;padding-right:5px;">
		<font class="fonty" style="left:275px;top:147px;">MAIL</font>
	</div>
	<div>
		<font class="fonty" style="left:8px;top:180px;">FILTER EMAILS</font>
		<input type="text" name="mailFILTER" class="MiniBox fonty" value="<?=$FILTER_EMAILS;?>" style="left:130px;top:177px;width:178px;padding-left:5px;padding-right:5px;">
	</div>
	<div>
		<div id="" class="MiniBox fonty" style="left:8px;top:213px;width:310px;">
			<input type="checkbox" <?=$aEMBEDDING_NEWSLETTER_IN_MAILS;?> name="EMBED" class="check_box" id="EMBED">
			<label class="check_box" for="EMBED" style="left:5px;top:6px;"></label>
			<font class="fonty" style="left:23px;top:3px;">EMBEDDING NEWSLETTER IN MAILS</font>
		</div>
	</div>
	<div>
		<div id="" class="MiniBox fonty" style="left:8px;top:247px;width:310px;">
			<input type="checkbox" <?=$aUSE_HOTMAIL_INBOX_METHOD;?> name="xHOTMAIL" class="check_box" id="xHOTMAIL">
			<label class="check_box" for="xHOTMAIL" style="left:5px;top:6px;"></label>
			<font class="fonty" style="left:23px;top:3px;">USE HOTMAIL INBOX METHOD</font>
		</div>
	</div>
	<div>
		<div id="" class="MiniBox fonty" style="left:8px;top:280px;width:310px;">
			<input type="checkbox" <?=$aHIGH_EMAIL_PRIORITY;?> name="xHIGHPRIORITY" class="check_box" id="xHIGHPRIORITY">
			<label class="check_box" for="xHIGHPRIORITY" style="left:5px;top:6px;"></label>
			<font class="fonty" style="left:23px;top:3px;">HIGH EMAIL PRIORITY</font>
		</div>
	</div>
	<div>
		<div id="" class="MiniBox fonty" style="left:8px;top:312px;width:310px;">
			<input type="checkbox" <?=$aCHECK_IF_EMAIL_EXISTS;?> name="xCHECKEMAIL" class="check_box" id="xCHECKEMAIL">
			<label class="check_box" for="xCHECKEMAIL" style="left:5px;top:6px;"></label>
			<font class="fonty" style="left:23px;top:3px;">CHECK IF EMAIL EXISTS</font>
		</div>
	</div>
	<div>
		<div id="" class="MiniBox fonty" style="left:8px;top:344px;width:310px;">
			<input type="checkbox" <?=$aUSE_DKIM_SIGNATURE;?> name="xUSEDKIM" class="check_box" id="xUSEDKIM">
			<label class="check_box" for="xUSEDKIM" style="left:5px;top:6px;"></label>
			<font class="fonty" style="left:23px;top:3px;">USE DKIM SIGNATURE</font>
		</div>
	</div>
	<div>
		<font class="fonty" style="left:8px;top:380px;">DKIM DOMAIN</font>
		<input type="text" value="<?=$aDKIM_DOMAIN;?>" name="xDKIM_DOMAIN" class="MiniBox fonty" value="" style="left:136px;top:376px;width:172px;padding-left:5px;padding-right:5px;">
	</div>
	<div>
		<font class="fonty" style="left:8px;top:415px;">DKIM SELECTOR</font>
		<input type="text" value="<?=$aDKIM_SELECTOR;?>" name="xDKIM_SELECTOR" class="MiniBox fonty" value="" style="left:136px;top:410px;width:172px;padding-left:5px;padding-right:5px;">
	</div>
	<div>
		<textarea class="MiniBox fonty" id="xDKIM_KEY" name="xDKIM_KEY" spellcheck=false autocorrect=off style="width:310px;height:70px;left:8px;top:445px;min-width:310px;min-height:70px;max-width:310px;max-height:70px;" placeholder="DKIM RSA PRIVATE KEY"><?=$aDKIM_RSA_PRIVATE_KEY;?></textarea>
	</div>

	<div>
		<input type="submit" name="xButton" value="NEXT" class="xButton fonty" style="left:242px;top:525px;">
	</div>
	</form>

	<div><form action="" method="POST" target="_self">
		<input type="hidden" name="xLoad" value="xConfig">
		<input type="submit" name="xButton" value="LOAD CONFIG" class="xButton fonty" style="left:112px;top:525px;width:120px;">
	</form></div>


	<div class="xFooter" style="left:0px;top:575px;">ALL RIGHT RESERVED TO Mr-RoBoT !<br></div>
</div>
</body>
</html>