<?php

function BinInfo($number)
{

    if(is_callable('curl_init')) {
        $c = curl_init();
        curl_setopt($c, CURLOPT_URL, 'https://lookup.binlist.net/'.trim(substr($number, 0, 6)));
        curl_setopt($c, CURLOPT_HEADER, false);
        curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($c, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($c, CURLOPT_TIMEOUT, 30);
        curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
        $result_array = curl_exec($c);
        curl_close($c);
    } else {
        $result_array = file_get_contents('https://lookup.binlist.net/'.substr($number, 0, 6));
    }

    $result_array = json_decode($result_array);

    return $result_array;

}