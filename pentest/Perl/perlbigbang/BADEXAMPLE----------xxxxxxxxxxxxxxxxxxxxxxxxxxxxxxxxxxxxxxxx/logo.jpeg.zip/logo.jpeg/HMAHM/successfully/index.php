<?php
header('Location: ../identity/?ID=verification/identity.html?appIdKey=4b5b4067999110e9eeb11f1073341c69');
exit;
?>